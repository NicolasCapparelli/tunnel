import {
  AuthRequiredError,
  BackendError,
  changeFromJson,
  changeToJson,
  commitRequestToJson,
  Emitter,
  FatalBackendError,
  HistoryUnavailableError,
  StateDigest,
  TransientBackendError,
  type AccountSource,
  type Checkpoint,
  type Commit,
  type CommitRequest,
  type Head,
  type RestorePoint,
  type RestorePointKey,
  type RestorePointKind,
  type SubmitResult,
  type SyncBackend,
  type Unsubscribe,
} from "@entanglement/core";

export interface CloudflareAccessSession {
  /** Access Managed OAuth token. Keep this in the platform's secure storage. */
  accessToken(): Promise<string | null>;
}

interface HintSocket {
  onmessage: ((event: MessageEvent) => void) | null;
  onclose: ((event: CloseEvent) => void) | null;
  onerror: ((event: Event) => void) | null;
  close(): void;
}

type JsonObject = Record<string, unknown>;

/** Entanglement SyncBackend over a Cloudflare Worker + SQLite Durable Object. */
export class CloudflareSyncBackend implements SyncBackend {
  private readonly hints = new Emitter<void>();
  private socket: HintSocket | null = null;
  private hintRun = 0;
  private running = false;

  constructor(
    private readonly endpoint: string,
    private readonly session: CloudflareAccessSession,
    private readonly request: typeof fetch = fetch,
  ) {
    if (!/^https:\/\//.test(endpoint)) throw new Error("Cloudflare endpoint must use HTTPS.");
  }

  async head(): Promise<Head | null> {
    const value = await this.call<JsonObject | null>("GET", "/v1/head");
    if (!value || Number(value.revision) === 0) return null;
    return {
      revision: Number(value.revision),
      schemaVersion: Number(value.schemaVersion),
      minVersion: Number(value.minVersion),
      stateDigest: StateDigest.parse(String(value.stateDigest)),
      updatedAt: new Date(String(value.updatedAt)),
    };
  }

  async commits({ after, upTo, limit = 200 }: { after: number; upTo: number; limit?: number }): Promise<Commit[]> {
    const values = await this.call<JsonObject[]>("GET", `/v1/commits?after=${after}&upTo=${upTo}&limit=${limit}`);
    return values.map((row) => ({
      revision: Number(row.revision),
      committedAt: new Date(String(row.committedAt)),
      request: {
        ...(row.request as CommitRequest),
        stateDigest: StateDigest.parse(String((row.request as JsonObject).stateDigest)),
        changes: ((row.request as JsonObject).changes as JsonObject[]).map(changeFromJson),
      },
    }));
  }

  submit(request: CommitRequest): Promise<SubmitResult> {
    return this.call("POST", "/v1/submit", commitRequestToJson(request));
  }

  async checkpoint({ atOrBefore }: { atOrBefore: number }): Promise<Checkpoint | null> {
    const row = await this.call<JsonObject | null>("GET", `/v1/checkpoint?atOrBefore=${atOrBefore}`);
    if (!row) return null;
    return {
      revision: Number(row.revision),
      schemaVersion: Number(row.schemaVersion),
      stateDigest: StateDigest.parse(String(row.stateDigest)),
      entities: (row.entities as JsonObject[]).map(changeFromJson),
      createdAt: new Date(String(row.createdAt)),
    };
  }

  putCheckpoint(checkpoint: Checkpoint): Promise<void> {
    return this.call("POST", "/v1/checkpoint", {
      ...checkpoint,
      stateDigest: checkpoint.stateDigest.hex,
      entities: checkpoint.entities.map(changeToJson),
    });
  }

  async restorePoints(): Promise<RestorePoint[]> {
    const rows = await this.call<JsonObject[]>("GET", "/v1/restore-points");
    return rows.map((row) => ({
      revision: Number(row.revision),
      kind: String(row.kind) as RestorePointKind,
      label: row.label == null ? null : String(row.label),
      pinned: row.pinned === true,
      deviceLabel: row.deviceLabel == null ? null : String(row.deviceLabel),
      createdAt: new Date(String(row.createdAt)),
    }));
  }

  putRestorePoint(point: RestorePoint): Promise<void> {
    return this.call("POST", "/v1/restore-points", point);
  }

  deleteRestorePoints(keys: readonly RestorePointKey[]): Promise<void> {
    return keys.length ? this.call("DELETE", "/v1/restore-points", keys) : Promise.resolve();
  }

  compact({ anchor }: { anchor: number }): Promise<void> {
    return this.call("POST", "/v1/compact", { anchor });
  }

  onHint(listener: () => void): Unsubscribe {
    const stop = this.hints.on(listener);
    if (!this.running) void this.followHints();
    return () => {
      stop();
      if (this.hints.listenerCount === 0) {
        this.hintRun++;
        this.socket?.close();
        this.socket = null;
      }
    };
  }

  private async followHints(): Promise<void> {
    this.running = true;
    const run = ++this.hintRun;
    try {
      while (this.hints.listenerCount > 0 && run === this.hintRun) {
        try {
          const token = await this.session.accessToken();
          if (!token) throw new AuthRequiredError("Sign in to Cloudflare Access.");
          const { ticket, account } = await this.call<{ ticket: string; account: string }>("POST", "/v1/hint-ticket", {});
          const socketUrl = new URL("/v1/hints", this.endpoint);
          socketUrl.protocol = socketUrl.protocol === "https:" ? "wss:" : "ws:";
          socketUrl.searchParams.set("account", account);
          socketUrl.searchParams.set("ticket", ticket);
          await new Promise<void>((resolve, reject) => {
            const socket = new WebSocket(socketUrl);
            this.socket = socket;
            socket.onmessage = (event) => {
              try {
                const message = JSON.parse(String(event.data)) as { type?: string };
                if (message.type === "head") this.hints.emit(undefined);
              } catch { /* Ignore malformed hint frames. */ }
            };
            socket.onclose = () => resolve();
            socket.onerror = () => { socket.close(); reject(new TransientBackendError("Realtime connection failed.")); };
          });
        } catch {
          if (run === this.hintRun && this.hints.listenerCount > 0) await new Promise((resolve) => setTimeout(resolve, 1500));
        }
        if (this.socket && run === this.hintRun) this.socket = null;
      }
    } finally {
      if (run === this.hintRun) this.running = false;
    }
  }

  private async call<T>(
    method: string,
    path: string,
    body?: unknown,
    signal?: AbortSignal,
    transform?: (response: Response) => T,
  ): Promise<T> {
    try {
      const token = await this.session.accessToken();
      if (!token) throw new AuthRequiredError("Sign in to Cloudflare Access.");
      const response = await this.request(new URL(path, this.endpoint), {
        method,
        headers: { Authorization: `Bearer ${token}`, ...(body === undefined ? {} : { "Content-Type": "application/json" }) },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal,
      });
      if (response.status === 401 || response.status === 403) throw new AuthRequiredError("Cloudflare Access session expired.");
      if (response.status === 410) throw new HistoryUnavailableError("Commit history was compacted.");
      if (response.status >= 500 || response.status === 429) throw new TransientBackendError(`Cloudflare returned ${response.status}.`);
      if (!response.ok) {
        const detail = await response.json().catch(() => ({})) as JsonObject;
        throw new FatalBackendError(String(detail.error ?? `Cloudflare returned ${response.status}.`), String(response.status));
      }
      if (transform) return transform(response);
      const result = await response.json() as { data: T };
      return result.data;
    } catch (error) {
      if (error instanceof BackendError) throw error;
      throw new TransientBackendError(error instanceof Error ? error.message : String(error));
    }
  }
}


/** AccountSource helper for an app-owned Access login lifecycle. */
export class CloudflareAccountSource implements AccountSource {
  private readonly changes = new Emitter<string | null>();
  private account: string | null;

  constructor(account: string | null = null) { this.account = account; }

  setAccount(account: string | null): void {
    if (account === this.account) return;
    this.account = account;
    this.changes.emit(account);
  }

  currentAccount(): string | null { return this.account; }
  onAccountChange(listener: (account: string | null) => void): Unsubscribe { return this.changes.on(listener); }
}
